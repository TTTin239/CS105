﻿
// ToMauEllipsesView.cpp : implementation of the CToMauEllipsesView class
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "ToMauEllipses.h"
#endif

#include "ToMauEllipsesDoc.h"
#include "ToMauEllipsesView.h"
#include "CDrawEllipse.h"
#include "CFill.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CToMauEllipsesView

IMPLEMENT_DYNCREATE(CToMauEllipsesView, CView)

BEGIN_MESSAGE_MAP(CToMauEllipsesView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CToMauEllipsesView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
END_MESSAGE_MAP()

// CToMauEllipsesView construction/destruction

CToMauEllipsesView::CToMauEllipsesView() noexcept
{
	// TODO: add construction code here

}

CToMauEllipsesView::~CToMauEllipsesView()
{
}

BOOL CToMauEllipsesView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CToMauEllipsesView drawing

void CToMauEllipsesView::OnDraw(CDC* pDC)
{
	CToMauEllipsesDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	CDrawEllipse::drawEllipse(pDC, 100, 100, 50, 30, RGB(255, 0, 0));
	CFill::BoundaryFill(pDC, 100, 100, RGB(128, 128, 128), RGB(255, 0, 0));		// Tô loang dùng đệ quy
	//CFill::BoundaryFillEnhanced(pDC, 100, 100,  RGB(0, 0, 255), RGB(255, 0, 0));		// Tô loang khử đệ quy bằng stack
	//CFill::BoundaryFillEnhanced(pDC, 100, 100, RGB(0, 255, 0));		// Tô loang khử đệ quy bằng stack - Tô không phụ thuộc màu biên
	// TODO: add draw code for native data here
}


// CToMauEllipsesView printing


void CToMauEllipsesView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CToMauEllipsesView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CToMauEllipsesView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CToMauEllipsesView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CToMauEllipsesView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CToMauEllipsesView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CToMauEllipsesView diagnostics

#ifdef _DEBUG
void CToMauEllipsesView::AssertValid() const
{
	CView::AssertValid();
}

void CToMauEllipsesView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CToMauEllipsesDoc* CToMauEllipsesView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CToMauEllipsesDoc)));
	return (CToMauEllipsesDoc*)m_pDocument;
}
#endif //_DEBUG


// CToMauEllipsesView message handlers
