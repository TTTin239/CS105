#pragma once
class CDrawEllipse
{
public:
	static void drawEllipse(CDC* pDC, int xc, int yc, int a, int b, COLORREF color);

};
