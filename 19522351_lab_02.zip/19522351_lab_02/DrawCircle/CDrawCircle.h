#pragma once
class CDrawCircle
{
public:

	static void drawCircleMidpoint(CDC* pDC, int xc, int yc, int r, COLORREF color);

};
